using System.Net;
using CoffeeNChill.Functions.Services;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Net.Http.Headers;

namespace CoffeeNChill.Functions.Functions;

public sealed class DocumentFunctions(DocumentService documents)
{
    [Function("ListStaffDocuments")]
    public async Task<HttpResponseData> List([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "documents")] HttpRequestData request) =>
        await request.JsonAsync(await documents.ListAsync());

    [Function("UploadStaffDocument")]
    public async Task<HttpResponseData> Upload([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "documents/upload")] HttpRequestData request)
    {
        if (!request.Headers.TryGetValues("Content-Type", out var values)
            || !MediaTypeHeaderValue.TryParse(values.FirstOrDefault(), out var contentType)
            || !contentType.MediaType.Equals("multipart/form-data", StringComparison.OrdinalIgnoreCase))
            return await request.ErrorAsync("Upload a file using multipart/form-data with the field name 'file'.");
        var boundary = HeaderUtilities.RemoveQuotes(contentType.Boundary).Value;
        if (string.IsNullOrWhiteSpace(boundary) || boundary.Length > 128) return await request.ErrorAsync("Invalid multipart boundary.");
        var reader = new MultipartReader(boundary, request.Body) { BodyLengthLimit = DocumentService.MaxBytes + 65536 };
        MultipartSection? section;
        while ((section = await reader.ReadNextSectionAsync()) is not null)
        {
            if (!ContentDispositionHeaderValue.TryParse(section.ContentDisposition, out var disposition)) continue;
            if (HeaderUtilities.RemoveQuotes(disposition.Name).Value != "file") continue;
            var name = HeaderUtilities.RemoveQuotes(disposition.FileNameStar.HasValue ? disposition.FileNameStar : disposition.FileName).Value;
            if (name is null) return await request.ErrorAsync("The file upload must have a file name.");
            // Optional name override keeps repeatable Postman runs from colliding with older fixtures.
            var uploadName = System.Web.HttpUtility.ParseQueryString(request.Url.Query)["fileName"] ?? name;
            var result = await documents.UploadAsync(uploadName, section.Body);
            return await request.JsonAsync(result, HttpStatusCode.Created);
        }
        return await request.ErrorAsync("No file was supplied. Use the multipart field name 'file'.");
    }

    [Function("DownloadStaffDocument")]
    public async Task<HttpResponseData> Download([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "documents/download/{fileName}")] HttpRequestData request, string fileName)
    {
        await using var stream = await documents.DownloadAsync(fileName);
        var response = request.CreateResponse(HttpStatusCode.OK);
        response.Headers.Add("Content-Type", DocumentService.ContentType(fileName));
        response.Headers.Add("Content-Disposition", $"attachment; filename*=UTF-8''{Uri.EscapeDataString(fileName)}");
        await stream.CopyToAsync(response.Body);
        return response;
    }
}
