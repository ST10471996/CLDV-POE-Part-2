# CoffeeNChill · Verification record

Checked on **12 October 2026** against the prepared source, with a running local Azure Functions host and actual Azurite storage. The dashboard preview is a browser capture of that application.

| Check | Result |
| --- | --- |
| Functions project Release build, targeting .NET 8 | Passed · 0 warnings, 0 errors |
| Integration project Release build | Passed · 0 warnings, 0 errors |
| Complete Postman collection | Passed · 34 defined requests, 49 executed requests including polling, 84 assertions, 0 failures |
| Live integration checks | Passed · 842 assertions, including repeated status observations |
| Menu insert, category queries, update, deletion and invalid inputs | Passed |
| Real queue producer and automatic QueueTrigger processing | Passed |
| Persisted Received → Preparing → Ready → Collected history | Passed |
| Completed message replay without duplicate Table rows/history | Passed |
| Recovery from a persisted Preparing row | Passed |
| Eight simultaneous orders | Passed |
| Document upload/list/download round trip in Local mode | Passed |
| Invalid document names and 10 MB upload limit | Passed · no partial file left after rejection |
| Browser order submission and displayed four-stage history | Passed |
| Browser staff library and menu editing dialog | Passed |
| Browser error/warning log during the inspected flow | No errors or warnings observed |
| JavaScript syntax check | Passed |
| Compose YAML parsing and published-image references | Passed · both services have `image:`, neither has `build:` |
| Referenced official Azurite base tag `3.37.0` | Confirmed present in Microsoft's container registry |

Assertion totals include polling and can vary between runs. The Postman fixture inserts test data and leaves orders/documents as evidence. It removes its temporary menu item. Integration tests use their own temporary menu fixture and remove it on successful completion.

## Test environment

- Windows, .NET SDK 10.0.401 compiling the `net8.0` projects.
- Azure Functions Core Tools 4.15.2, Functions host 4.1053.200.26403.
- The local Functions worker ran using the installed .NET 10 runtime with major-version roll-forward. The independent integration runner used a local .NET 8.0.31 runtime.
- Azurite 3.37.0, with the normal local development storage account.
- Newman 6.2.3.
- Staff documents were tested using the labelled Local development provider.

For ordinary development, follow the README's .NET 8 SDK prerequisites. The Dockerfile targets Microsoft's .NET 8 isolated Functions image.

## Still to verify with your accounts

**Docker execution was not tested here:** Docker Desktop/the Docker CLI was unavailable. The Compose file was parsed and its image references were checked, but the images were not built, pushed, pulled or started as containers.

**Real Azure Files was not tested here:** no Azure account connection string was supplied. The Azure Files implementation compiles against the official SDK, but you must configure and demonstrate the actual `staff-docs` share for that requirement. Local mode does not satisfy evidence of a real Azure File Share.

GitHub publication, student contributions, Docker Hub publication and the unlisted human-voiced YouTube demonstration require your own accounts and genuine evidence. The prepared project does not claim those steps have happened.
