using CoffeeNChill.Functions.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication(worker => worker.UseMiddleware<ErrorMiddleware>())
    .ConfigureServices(services =>
    {
        services.AddSingleton<StorageService>();
        services.AddSingleton<DocumentService>();
    })
    .Build();
host.Run();
