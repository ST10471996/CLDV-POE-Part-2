# CoffeeNChill · Demonstration outline

Present the application as a continuation of the canteen's cloud foundation. Use your own voice and explain the decisions in your own words.

1. **Introduce the canteen.** Show the single dashboard: menu, basket, order board and staff documents. Explain the queues at lecture breaks and how the earlier menu/document work now supports ordering.
2. **Show the published images.** Open your public Docker Hub repositories. Point out `coffeenchill-functions:v2.0` and `coffeenchill-azurite:v1.0`. Show the root Compose `image:` entries and the absence of local `build:` entries.
3. **Start the services.** Run `docker compose up` (or the available `docker-compose up`). Show Azurite becoming healthy and the Functions host exposing the HTTP routes and `ProcessOrderQueue`.
4. **Demonstrate continuity.** Browse the menu, filter a category, update a price/availability and upload/download a staff guide. For real Azure Files evidence, show the `staff-docs` share in your Azure account and the dashboard reporting AzureFiles mode. Do not display connection-string secrets.
5. **Place an order.** Add menu favourites to the basket and enter a name. Explain that HTTP returns 202 as soon as the JSON is queued, while the background trigger processes independently.
6. **Follow the same order.** Show Received, Preparing, Ready and Collected on the board. Open its timestamp history and the Functions logs. Explain that preparation and collection are simulated automatically in this stage.
7. **Walk through the code.** Show the producer, the `QueueTrigger` attribute, Table keys, Base64 settings and ETag-protected updates. Explain duplicate delivery and the poison queue after exhausted retries.
8. **Run the complete Postman collection.** Show real passing assertions, including the polling request and final four-stage history. Explain that the uploaded fixture and order remain as evidence while the temporary menu item is removed.
9. **Show teamwork evidence.** Open the repository history and explain each member's actual contributions. Confirm the README contains your current unlisted YouTube link and published image links.

Before recording, use the unchanged sample Espresso/Croissant prices (R28/R37). Keep `OrderStepDelayMs=4000` for visible stages. Use your real accounts and an actual recording of the running system.
