using System.Net;
using CoffeeNChill.Functions.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;

namespace CoffeeNChill.Functions.Functions;

public sealed class AppFunctions(StorageService storage, DocumentService documents)
{
    [Function("Dashboard")]
    public async Task<HttpResponseData> App([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "app/{asset?}")] HttpRequestData request, string? asset)
    {
        asset ??= "index.html";
        var type = asset switch { "index.html" => "text/html", "app.css" => "text/css", "app.js" => "text/javascript", _ => null };
        if (type is null) return request.CreateResponse(HttpStatusCode.NotFound);
        var response = request.CreateResponse(HttpStatusCode.OK);
        response.Headers.Add("Content-Type", $"{type}; charset=utf-8");
        response.Headers.Add("X-Content-Type-Options", "nosniff");
        response.Headers.Add("Cache-Control", "no-cache");
        await using var stream = File.OpenRead(Path.Combine(AppContext.BaseDirectory, "www", asset));
        await stream.CopyToAsync(response.Body);
        return response;
    }

    [Function("Health")]
    public async Task<HttpResponseData> Health([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "health")] HttpRequestData request)
    {
        await storage.EnsureAsync();
        await storage.Queue.GetPropertiesAsync();
        return await request.JsonAsync(new { status = "healthy", version = "2.0.0", menuTable = "MenuItems", ordersTable = "Orders",
            queue = StorageService.QueueName, documentsProvider = documents.Provider, orderStatuses = new[] { "Received", "Preparing", "Ready", "Collected" } });
    }
}
