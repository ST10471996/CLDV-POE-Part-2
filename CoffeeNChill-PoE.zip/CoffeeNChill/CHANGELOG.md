# CoffeeNChill · Project evolution

The canteen grows in one continuous application. Earlier features stay available as new workflows are introduced.

## v2.0.0 · Asynchronous orders and orchestration

- Continued the menu and staff document foundation inside the same Azure Functions project.
- Added `POST /api/orders/queue` with validation, menu-derived pricing and immediate 202 acknowledgement.
- Added `ProcessOrderQueue` with the required Azure Queue trigger.
- Persisted orders in the `Orders` table using UTC order date and order ID keys.
- Simulated Received → Preparing → Ready → Collected with timestamped history.
- Added order queries and queue metadata so status changes can be demonstrated through HTTP and Postman.
- Handled duplicate queue deliveries with state resumption and optimistic Table concurrency.
- Added a root Compose configuration that references published Docker Hub images.
- Added one responsive dashboard covering ordering, operations and staff documents.
- Extended the Postman collection across the complete workflow, including invalid requests and final stored history.
- Documented real Azure Files and the local development fallback, because Azurite cannot emulate Files.

## Foundation retained in the current release

- Azure `MenuItems` Table and HTTP functions to create, list, filter, update and delete menu entries.
- Staff document upload, listing and download functions, with a real `staff-docs` Azure File Share option.
- Azurite development configuration and standalone Docker execution instructions.
- A multi-stage Dockerfile using Microsoft's isolated .NET 8 Functions runtime.

This foundation is reconstructed within the supplied complete project. No original student repository was supplied, so this changelog does not assert historical v1.0 commits, deployments or completed submissions.
