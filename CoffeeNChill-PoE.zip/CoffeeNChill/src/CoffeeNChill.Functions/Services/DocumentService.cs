using Azure;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using CoffeeNChill.Functions.Models;

namespace CoffeeNChill.Functions.Services;

public sealed class DocumentService
{
    public const long MaxBytes = 10 * 1024 * 1024;
    public string Provider { get; }
    private readonly string localPath;
    private readonly ShareClient? share;

    public DocumentService()
    {
        Provider = Environment.GetEnvironmentVariable("DocumentsProvider") ?? "Local";
        localPath = Path.GetFullPath(Environment.GetEnvironmentVariable("StaffDocsPath") ?? "./data/staff-docs");
        if (Provider.Equals("AzureFiles", StringComparison.OrdinalIgnoreCase))
        {
            var connection = Environment.GetEnvironmentVariable("AzureFilesConnectionString");
            if (string.IsNullOrWhiteSpace(connection)) throw new InvalidOperationException("AzureFilesConnectionString is required for AzureFiles mode.");
            share = new ShareClient(connection, "staff-docs");
            Provider = "AzureFiles";
        }
        else if (Provider.Equals("Local", StringComparison.OrdinalIgnoreCase)) Provider = "Local";
        else throw new InvalidOperationException("DocumentsProvider must be Local or AzureFiles.");
    }

    public static bool ValidFileName(string name) => !string.IsNullOrWhiteSpace(name) && name.Length <= 120
        && name is not "." and not ".." && !name.Any(c => c < 32 || "\\/:*?\"<>|#".Contains(c))
        && new[] { ".pdf", ".txt", ".md", ".docx", ".png", ".jpg", ".jpeg" }.Contains(Path.GetExtension(name).ToLowerInvariant());

    public async Task<DocumentView> UploadAsync(string name, Stream source)
    {
        if (!ValidFileName(name)) throw new InvalidDataException("Use a valid PDF, TXT, MD, DOCX, PNG or JPG file name.");
        if (share is null)
        {
            Directory.CreateDirectory(localPath);
            var path = Path.Combine(localPath, name);
            if (File.Exists(path)) throw new InvalidDataException("A document with this name already exists. Rename the upload.");
            var temporaryPath = Path.Combine(localPath, $".upload-{Guid.NewGuid():N}.tmp");
            try
            {
                await using (var destination = new FileStream(temporaryPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536, true))
                    await CopyBoundedAsync(source, destination);
                File.Move(temporaryPath, path, false);
            }
            catch (IOException) when (File.Exists(path)) { throw new InvalidDataException("A document with this name already exists. Rename the upload."); }
            finally { if (File.Exists(temporaryPath)) File.Delete(temporaryPath); }
            var info = new FileInfo(path);
            return new(name, info.Length, info.LastWriteTimeUtc);
        }
        await share.CreateIfNotExistsAsync();
        var file = share.GetRootDirectoryClient().GetFileClient(name);
        if ((await file.ExistsAsync()).Value) throw new InvalidDataException("A document with this name already exists. Rename the upload.");
        // Fixed-size blocks are streamed from the multipart body directly to Azure Files.
        // No full uploaded document is held in memory or staged on disk in AzureFiles mode.
        await file.CreateAsync(MaxBytes);
        long offset = 0;
        try
        {
            var buffer = new byte[65536];
            int read;
            while ((read = await source.ReadAsync(buffer)) > 0)
            {
                if (offset + read > MaxBytes) throw new InvalidDataException("The maximum document size is 10 MB.");
                using var chunk = new MemoryStream(buffer, 0, read, false);
                await file.UploadRangeAsync(new HttpRange(offset, read), chunk);
                offset += read;
            }
            if (offset == 0) throw new InvalidDataException("The uploaded document is empty.");
            await file.SetHttpHeadersAsync(new ShareFileSetHttpHeadersOptions { NewSize = offset,
                HttpHeaders = new ShareFileHttpHeaders { ContentType = ContentType(name) } });
        }
        catch { await file.DeleteIfExistsAsync(); throw; }
        var properties = await file.GetPropertiesAsync();
        return new(name, offset, properties.Value.LastModified);
    }

    private static async Task CopyBoundedAsync(Stream source, Stream target)
    {
        var buffer = new byte[65536];
        long total = 0;
        int read;
        while ((read = await source.ReadAsync(buffer)) > 0)
        {
            total += read;
            if (total > MaxBytes) throw new InvalidDataException("The maximum document size is 10 MB.");
            await target.WriteAsync(buffer.AsMemory(0, read));
        }
        if (total == 0) throw new InvalidDataException("The uploaded document is empty.");
    }

    public async Task<List<DocumentView>> ListAsync()
    {
        if (share is null)
        {
            Directory.CreateDirectory(localPath);
            return new DirectoryInfo(localPath).GetFiles().Where(x => ValidFileName(x.Name))
                .OrderBy(x => x.Name).Select(x => new DocumentView(x.Name, x.Length, x.LastWriteTimeUtc)).ToList();
        }
        await share.CreateIfNotExistsAsync();
        var directory = share.GetRootDirectoryClient();
        var items = new List<DocumentView>();
        await foreach (var entry in directory.GetFilesAndDirectoriesAsync())
        {
            if (entry.IsDirectory) continue;
            var properties = await directory.GetFileClient(entry.Name).GetPropertiesAsync();
            items.Add(new(entry.Name, properties.Value.ContentLength, properties.Value.LastModified));
        }
        return items.OrderBy(x => x.FileName).ToList();
    }

    public async Task<Stream> DownloadAsync(string name)
    {
        if (!ValidFileName(name)) throw new InvalidDataException("Invalid document name.");
        if (share is null) return new FileStream(Path.Combine(localPath, name), FileMode.Open, FileAccess.Read, FileShare.Read, 65536, true);
        var result = await share.GetRootDirectoryClient().GetFileClient(name).DownloadAsync();
        return result.Value.Content;
    }

    public static string ContentType(string name) => Path.GetExtension(name).ToLowerInvariant() switch
    {
        ".pdf" => "application/pdf", ".png" => "image/png", ".jpg" or ".jpeg" => "image/jpeg",
        ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        _ => "text/plain; charset=utf-8"
    };
}
