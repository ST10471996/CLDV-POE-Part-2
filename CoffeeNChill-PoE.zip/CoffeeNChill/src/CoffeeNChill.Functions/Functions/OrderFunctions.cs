using System.Globalization;
using System.Net;
using System.Text.Json;
using Azure;
using Azure.Data.Tables;
using CoffeeNChill.Functions.Models;
using CoffeeNChill.Functions.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace CoffeeNChill.Functions.Functions;

public sealed class OrderFunctions(StorageService storage, ILogger<OrderFunctions> logger)
{
    private static readonly string[] Stages = ["Received", "Preparing", "Ready", "Collected"];

    [Function("QueueOrder")]
    public async Task<HttpResponseData> Queue([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "orders/queue")] HttpRequestData request)
    {
        var input = await request.ReadAsync<OrderInput>();
        if (input is null || string.IsNullOrWhiteSpace(input.CustomerName) || input.CustomerName.Length > 80
            || input.SelectedItemSKUs is null || input.SelectedItemSKUs.Length is < 1 or > 50
            || input.SelectedItemSKUs.Any(x => !StorageService.ValidKey(x, 60)))
            return await request.ErrorAsync("Supply a customer name and between 1 and 50 valid item SKUs.");
        var id = input.OrderId ?? $"ORD-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..10].ToUpperInvariant()}";
        if (!StorageService.ValidKey(id, 80)) return await request.ErrorAsync("OrderId contains invalid characters.");
        if (await storage.FindOrderAsync(id) is not null)
            return await request.ErrorAsync("This order ID has already been processed. Use a new ID.", HttpStatusCode.Conflict);
        var menu = await storage.GetMenuAsync();
        decimal total = 0;
        foreach (var sku in input.SelectedItemSKUs)
        {
            var matches = menu.Where(x => x.Id == sku).ToArray();
            if (matches.Length != 1 || !matches[0].IsAvailable) return await request.ErrorAsync($"Item {sku} is unavailable or does not exist.");
            total += (decimal)matches[0].Price;
        }
        total = Math.Round(total, 2);
        if (input.TotalPrice.HasValue && input.TotalPrice.Value != total)
            return await request.ErrorAsync($"The current menu total is {total.ToString("0.00", CultureInfo.InvariantCulture)}. Refresh the menu and try again.");
        var timestamp = (input.OrderTimestamp ?? DateTimeOffset.UtcNow).ToUniversalTime();
        if (timestamp.Year < 1601) return await request.ErrorAsync("OrderTimestamp must be on or after 1601-01-01 for Azure Table Storage.");
        var order = new OrderMessage(id, input.CustomerName.Trim(), input.SelectedItemSKUs, total, timestamp);
        await storage.Queue.SendMessageAsync(JsonSerializer.Serialize(order, HttpResponses.Json));
        logger.LogInformation("Order {OrderId} enqueued; customer request is now complete.", id);
        return await request.JsonAsync(new { orderId = id, status = "Queued", totalPrice = total, orderTimestamp = timestamp,
            statusUrl = $"/api/orders/status/{Uri.EscapeDataString(id)}" }, HttpStatusCode.Accepted, new()
        {
            ["Location"] = $"/api/orders/status/{Uri.EscapeDataString(id)}"
        });
    }

    [Function("GetOrders")]
    public async Task<HttpResponseData> All([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "orders")] HttpRequestData request)
    {
        var date = System.Web.HttpUtility.ParseQueryString(request.Url.Query)["date"] ?? DateTime.UtcNow.ToString("yyyy-MM-dd");
        if (!DateOnly.TryParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
            return await request.ErrorAsync("Use an order date in yyyy-MM-dd format (UTC).");
        return await request.JsonAsync(await storage.GetOrdersAsync(date));
    }

    [Function("GetOrderStatus")]
    public async Task<HttpResponseData> One([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "orders/status/{id}")] HttpRequestData request, string id)
    {
        if (!StorageService.ValidKey(id, 80)) return await request.ErrorAsync("Invalid order ID.");
        var order = await storage.FindOrderAsync(id);
        return order is null ? await request.ErrorAsync("Order not found. A newly queued order may take a moment to appear.", HttpStatusCode.NotFound)
            : await request.JsonAsync(order.View());
    }

    [Function("GetQueueInfo")]
    public async Task<HttpResponseData> QueueInfo([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "orders/queue-info")] HttpRequestData request)
    {
        await storage.EnsureAsync();
        var properties = await storage.Queue.GetPropertiesAsync();
        return await request.JsonAsync(new { name = StorageService.QueueName, approximateMessageCount = properties.Value.ApproximateMessagesCount });
    }

    [Function("ProcessOrderQueue")]
    public async Task Process([QueueTrigger("order-processing-queue", Connection = "AzureWebJobsStorage")] string payload, CancellationToken cancellationToken)
    {
        var order = JsonSerializer.Deserialize<OrderMessage>(payload, HttpResponses.Json)
            ?? throw new InvalidDataException("Order message is empty.");
        if (!StorageService.ValidKey(order.OrderId, 80) || string.IsNullOrWhiteSpace(order.CustomerName)
            || order.CustomerName.Length > 80 || order.SelectedItemSKUs is null || order.SelectedItemSKUs.Length is < 1 or > 50
            || order.TotalPrice < 0 || order.OrderTimestamp.Year < 1601 || order.SelectedItemSKUs.Any(x => !StorageService.ValidKey(x, 60)))
            throw new InvalidDataException("Queue payload contains invalid order data.");
        await storage.EnsureAsync();
        var date = order.OrderTimestamp.UtcDateTime.ToString("yyyy-MM-dd");
        var entity = new OrderEntity { PartitionKey = date, RowKey = order.OrderId, CustomerName = order.CustomerName,
            SelectedItemSKUs = JsonSerializer.Serialize(order.SelectedItemSKUs), TotalPrice = (double)order.TotalPrice,
            OrderTimestamp = order.OrderTimestamp.ToUniversalTime(), Status = "Received",
            StatusHistory = JsonSerializer.Serialize(new[] { new OrderEvent("Received", DateTimeOffset.UtcNow) }) };
        try
        {
            await storage.Orders.AddEntityAsync(entity, cancellationToken);
            logger.LogInformation("Order {OrderId}: Received", order.OrderId);
        }
        catch (RequestFailedException e) when (e.Status == 409)
        {
            logger.LogInformation("Order {OrderId} already exists; resume its recorded progress.", order.OrderId);
        }
        var stepDelay = int.TryParse(Environment.GetEnvironmentVariable("OrderStepDelayMs"), out var delay) ? Math.Clamp(delay, 250, 60000) : 4000;
        while (!cancellationToken.IsCancellationRequested)
        {
            entity = (await storage.Orders.GetEntityAsync<OrderEntity>(date, order.OrderId, cancellationToken: cancellationToken)).Value;
            if (entity.CustomerName != order.CustomerName || entity.SelectedItemSKUs != JsonSerializer.Serialize(order.SelectedItemSKUs)
                || entity.TotalPrice != (double)order.TotalPrice)
                throw new InvalidDataException("A different payload reused an existing order ID.");
            var stage = Array.IndexOf(Stages, entity.Status);
            if (stage < 0) throw new InvalidDataException("Unknown persisted status.");
            if (stage == Stages.Length - 1) return;
            await Task.Delay(stepDelay, cancellationToken);
            entity.Status = Stages[stage + 1];
            var history = JsonSerializer.Deserialize<List<OrderEvent>>(entity.StatusHistory) ?? [];
            history.Add(new OrderEvent(entity.Status, DateTimeOffset.UtcNow));
            entity.StatusHistory = JsonSerializer.Serialize(history);
            try
            {
                // ETag prevents a duplicate queue delivery from moving an order backwards.
                await storage.Orders.UpdateEntityAsync(entity, entity.ETag, TableUpdateMode.Replace, cancellationToken);
                logger.LogInformation("Order {OrderId}: {Status}", order.OrderId, entity.Status);
            }
            catch (RequestFailedException e) when (e.Status == 412) { /* Read the latest state and resume. */ }
        }
        cancellationToken.ThrowIfCancellationRequested();
    }
}
