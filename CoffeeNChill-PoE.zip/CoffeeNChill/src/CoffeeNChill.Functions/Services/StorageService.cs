using Azure;
using Azure.Data.Tables;
using Azure.Storage.Queues;
using CoffeeNChill.Functions.Models;

namespace CoffeeNChill.Functions.Services;

public sealed class StorageService
{
    public const string QueueName = "order-processing-queue";
    public TableClient Menu { get; }
    public TableClient Orders { get; }
    public QueueClient Queue { get; }
    private readonly SemaphoreSlim initialization = new(1);
    private bool initialized;

    public StorageService()
    {
        var connection = Environment.GetEnvironmentVariable("AzureWebJobsStorage")
            ?? throw new InvalidOperationException("AzureWebJobsStorage must be configured.");
        Menu = new TableClient(connection, "MenuItems");
        Orders = new TableClient(connection, "Orders");
        Queue = new QueueClient(connection, QueueName, new QueueClientOptions { MessageEncoding = QueueMessageEncoding.Base64 });
    }

    public async Task EnsureAsync()
    {
        if (initialized) return;
        await initialization.WaitAsync();
        try
        {
            if (initialized) return;
            await Menu.CreateIfNotExistsAsync();
            await Orders.CreateIfNotExistsAsync();
            await Queue.CreateIfNotExistsAsync();
            initialized = true;
        }
        finally { initialization.Release(); }
    }

    public async Task<List<MenuView>> GetMenuAsync(string? category = null)
    {
        await EnsureAsync();
        var results = new List<MenuView>();
        var filter = category is null ? null : TableClient.CreateQueryFilter($"PartitionKey eq {category}");
        await foreach (var item in Menu.QueryAsync<MenuEntity>(filter)) results.Add(item.View());
        return results.OrderBy(x => x.Category).ThenBy(x => x.Name).ToList();
    }

    public async Task<OrderEntity?> FindOrderAsync(string id, string? date = null)
    {
        await EnsureAsync();
        if (date is not null)
        {
            var row = await Orders.GetEntityIfExistsAsync<OrderEntity>(date, id);
            return row.HasValue ? row.Value : null;
        }
        await foreach (var row in Orders.QueryAsync<OrderEntity>(TableClient.CreateQueryFilter($"RowKey eq {id}"))) return row;
        return null;
    }

    public async Task<List<OrderView>> GetOrdersAsync(string date)
    {
        await EnsureAsync();
        var results = new List<OrderView>();
        await foreach (var row in Orders.QueryAsync<OrderEntity>(TableClient.CreateQueryFilter($"PartitionKey eq {date}"))) results.Add(row.View());
        return results.OrderByDescending(x => x.OrderTimestamp).ToList();
    }

    public static bool ValidKey(string? value, int maxLength = 100) =>
        !string.IsNullOrWhiteSpace(value) && value.Length <= maxLength && !value.Any(c => c < 32 || c is '/' or '\\' or '#' or '?');

    public async Task<int> SeedAsync()
    {
        await EnsureAsync();
        MenuInput[] items =
        [
            new("Hot Drinks", "COF-001", "Espresso", "A bold, beautifully balanced double shot.", 28),
            new("Hot Drinks", "COF-002", "Cappuccino", "Rich espresso, steamed milk and a soft foam crown.", 36),
            new("Hot Drinks", "COF-003", "Vanilla latte", "Smooth espresso with milk and a touch of vanilla.", 42),
            new("Cold Drinks", "ICE-001", "Iced coffee", "Slow moments, cold coffee. Served over ice.", 38),
            new("Cold Drinks", "TEA-001", "Peach iced tea", "Freshly brewed tea with a bright peach finish.", 30),
            new("Pastries", "PAS-104", "Butter croissant", "Golden, flaky layers, baked fresh each morning.", 37),
            new("Pastries", "PAS-105", "Chocolate muffin", "A soft chocolate muffin with a generous centre.", 32),
            new("Sandwiches", "SAN-001", "Toasted cheese", "Melted cheddar on toasted sourdough.", 48),
            new("Sandwiches", "SAN-002", "Chicken & avo", "Roast chicken, avocado and crisp greens.", 65)
        ];
        var count = 0;
        foreach (var item in items)
        {
            try
            {
                await Menu.AddEntityAsync(new MenuEntity { PartitionKey = item.Category!, RowKey = item.Id!, Name = item.Name!,
                    Description = item.Description!, Price = item.Price, IsAvailable = item.IsAvailable });
                count++;
            }
            catch (RequestFailedException e) when (e.Status == 409) { /* Existing staff edits are preserved. */ }
        }
        return count;
    }
}
