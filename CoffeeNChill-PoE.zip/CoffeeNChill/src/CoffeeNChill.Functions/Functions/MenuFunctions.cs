using System.Net;
using CoffeeNChill.Functions.Models;
using CoffeeNChill.Functions.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;

namespace CoffeeNChill.Functions.Functions;

public sealed class MenuFunctions(StorageService storage)
{
    [Function("GetAllMenuItems")]
    public async Task<HttpResponseData> All([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "menu")] HttpRequestData request) =>
        await request.JsonAsync(await storage.GetMenuAsync());

    [Function("GetMenuItemsByCategory")]
    public async Task<HttpResponseData> Category([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "menu/category/{category}")] HttpRequestData request, string category) =>
        await request.JsonAsync(await storage.GetMenuAsync(category));

    [Function("CreateMenuItem")]
    public async Task<HttpResponseData> Create([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "menu")] HttpRequestData request)
    {
        var item = await request.ReadAsync<MenuInput>();
        if (item is null || !StorageService.ValidKey(item.Category) || !StorageService.ValidKey(item.Id, 60)
            || string.IsNullOrWhiteSpace(item.Name) || item.Name.Length > 100 || (item.Description?.Length ?? 0) > 500
            || !double.IsFinite(item.Price) || item.Price < 0 || item.Price > 10000)
            return await request.ErrorAsync("Provide a category, unique SKU, name and a price between 0 and 10000.");
        await storage.EnsureAsync();
        // A SKU is unique across categories so orders can resolve the item unambiguously.
        if ((await storage.GetMenuAsync()).Any(x => x.Id == item.Id))
            return await request.ErrorAsync("This SKU already exists.", HttpStatusCode.Conflict);
        var entity = new MenuEntity { PartitionKey = item.Category!, RowKey = item.Id!, Name = item.Name.Trim(),
            Description = item.Description?.Trim() ?? "", Price = Math.Round(item.Price, 2), IsAvailable = item.IsAvailable };
        await storage.Menu.AddEntityAsync(entity);
        return await request.JsonAsync(entity.View(), HttpStatusCode.Created, new()
        {
            ["Location"] = $"/api/menu/{Uri.EscapeDataString(entity.PartitionKey)}/{Uri.EscapeDataString(entity.RowKey)}"
        });
    }

    [Function("UpdateMenuItem")]
    public async Task<HttpResponseData> Update([HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = "menu/{category}/{id}")] HttpRequestData request, string category, string id)
    {
        var input = await request.ReadAsync<MenuUpdate>();
        if (input is null || (input.Price is null && input.IsAvailable is null)
            || (input.Price is double price && (!double.IsFinite(price) || price < 0 || price > 10000)))
            return await request.ErrorAsync("Supply a valid price and/or availability status.");
        await storage.EnsureAsync();
        var item = (await storage.Menu.GetEntityAsync<MenuEntity>(category, id)).Value;
        if (input.Price.HasValue) item.Price = Math.Round(input.Price.Value, 2);
        if (input.IsAvailable.HasValue) item.IsAvailable = input.IsAvailable.Value;
        await storage.Menu.UpdateEntityAsync(item, item.ETag, Azure.Data.Tables.TableUpdateMode.Replace);
        return await request.JsonAsync(item.View());
    }

    [Function("DeleteMenuItem")]
    public async Task<HttpResponseData> Delete([HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "menu/{category}/{id}")] HttpRequestData request, string category, string id)
    {
        await storage.EnsureAsync();
        var item = await storage.Menu.GetEntityAsync<MenuEntity>(category, id);
        await storage.Menu.DeleteEntityAsync(category, id, item.Value.ETag);
        return request.CreateResponse(HttpStatusCode.NoContent);
    }

    [Function("SeedSampleMenu")]
    public async Task<HttpResponseData> Seed([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "menu/seed")] HttpRequestData request) =>
        await request.JsonAsync(new { added = await storage.SeedAsync(), message = "Sample menu added. Existing entries were preserved." });
}
