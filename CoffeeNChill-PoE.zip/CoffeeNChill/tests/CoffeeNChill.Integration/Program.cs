using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Azure.Data.Tables;
using Azure.Storage.Queues;

var url = args.FirstOrDefault() ?? "http://localhost:7071";
using var http = new HttpClient { BaseAddress = new Uri(url), Timeout = TimeSpan.FromSeconds(30) };
var jsonOptions = new JsonSerializerOptions(JsonSerializerDefaults.Web);
var suffix = Guid.NewGuid().ToString("N")[..12];
var assertions = 0;
var fixtureId = $"TST-{suffix}";
var fixtureName = $"integration-{suffix}.txt";
var date = DateTimeOffset.UtcNow.ToString("yyyy-MM-dd");
Console.WriteLine($"Testing live Functions host: {url}");

void Assert(bool condition, string description)
{
    if (!condition) throw new Exception($"FAILED: {description}");
    assertions++;
}
async Task<JsonElement> Call(string method, string path, object? body = null, HttpStatusCode expected = HttpStatusCode.OK)
{
    using var request = new HttpRequestMessage(new HttpMethod(method), "/api" + path);
    if (body is not null) request.Content = JsonContent.Create(body, options: jsonOptions);
    using var response = await http.SendAsync(request);
    var text = await response.Content.ReadAsStringAsync();
    Assert(response.StatusCode == expected, $"{method} {path}: expected {(int)expected}, got {(int)response.StatusCode} {text}");
    return text.Length == 0 ? default : JsonDocument.Parse(text).RootElement.Clone();
}
async Task<JsonElement> AwaitCollected(string id)
{
    var previous = -1;
    var deadline = DateTime.UtcNow.AddSeconds(65);
    while (DateTime.UtcNow < deadline)
    {
        using var response = await http.GetAsync("/api/orders/status/" + id);
        if (response.StatusCode == HttpStatusCode.NotFound) { await Task.Delay(300); continue; }
        Assert(response.IsSuccessStatusCode, $"Status query for {id} is successful");
        var row = JsonDocument.Parse(await response.Content.ReadAsStringAsync()).RootElement.Clone();
        var stage = Array.IndexOf(new[] { "Received", "Preparing", "Ready", "Collected" }, row.GetProperty("status").GetString());
        Assert(stage >= previous, $"{id}: progress never moves backwards"); previous = stage;
        if (stage == 3)
        {
            var history = row.GetProperty("history").EnumerateArray().ToArray();
            Assert(history.Select(x => x.GetProperty("status").GetString()).SequenceEqual(new[] { "Received", "Preparing", "Ready", "Collected" }), "Complete persisted four-stage history");
            for (var i = 1; i < history.Length; i++)
                Assert(history[i].GetProperty("timestamp").GetDateTimeOffset() >= history[i - 1].GetProperty("timestamp").GetDateTimeOffset(), "Chronological history timestamps");
            return row;
        }
        await Task.Delay(300);
    }
    throw new Exception($"Order {id} did not complete in 65 seconds.");
}

try
{
    var health = await Call("GET", "/health");
    Assert(health.GetProperty("status").GetString() == "healthy", "Real storage connectivity");
    await Call("POST", "/menu/seed", new { });
    await Call("POST", "/menu", new { Category = "Hot Drinks", Id = fixtureId, Name = "Integration coffee", Description = "Temporary test fixture", Price = 19.5, IsAvailable = true }, HttpStatusCode.Created);
    await Call("POST", "/menu", new { Category = "Pastries", Id = fixtureId, Name = "Duplicate SKU", Price = 20 }, HttpStatusCode.Conflict);
    var category = await Call("GET", "/menu/category/Hot%20Drinks");
    Assert(category.EnumerateArray().Any(x => x.GetProperty("id").GetString() == fixtureId), "Menu insert persisted");
    await Call("PUT", $"/menu/Hot%20Drinks/{fixtureId}", new { Price = 20.25, IsAvailable = false });
    await Call("POST", "/orders/queue", new { CustomerName = "Tester", SelectedItemSKUs = new[] { fixtureId } }, HttpStatusCode.BadRequest);
    await Call("PUT", $"/menu/Hot%20Drinks/{fixtureId}", new { IsAvailable = true });
    await Call("POST", "/orders/queue", new { CustomerName = "Tester", SelectedItemSKUs = new[] { fixtureId }, TotalPrice = 1 }, HttpStatusCode.BadRequest);
    await Call("POST", "/orders/queue", new { CustomerName = "Tester", SelectedItemSKUs = Array.Empty<string>() }, HttpStatusCode.BadRequest);
    await Call("POST", "/orders/queue", new { CustomerName = "Tester", SelectedItemSKUs = Enumerable.Repeat(fixtureId, 51).ToArray() }, HttpStatusCode.BadRequest);

    using (var malformed = await http.PostAsync("/api/menu", new StringContent("{bad-json", Encoding.UTF8, "application/json")))
        Assert(malformed.StatusCode == HttpStatusCode.BadRequest, "Malformed JSON produces 400");

    var firstId = $"ORD-INTEGRATION-{suffix}";
    var firstTime = DateTimeOffset.UtcNow;
    var firstPayload = new { OrderId = firstId, CustomerName = "Integration tester", SelectedItemSKUs = new[] { fixtureId, fixtureId }, TotalPrice = 40.5m, OrderTimestamp = firstTime };
    var accepted = await Call("POST", "/orders/queue", firstPayload, HttpStatusCode.Accepted);
    Assert(accepted.GetProperty("status").GetString() == "Queued", "HTTP completes before preparation");
    Assert(accepted.GetProperty("totalPrice").GetDecimal() == 40.5m, "Repeated SKUs represent quantity");
    var completed = await AwaitCollected(firstId);
    Assert(completed.GetProperty("orderDate").GetString() == date, "UTC Table PartitionKey is exposed correctly");
    await Call("POST", "/orders/queue", firstPayload, HttpStatusCode.Conflict);
    Console.WriteLine("PASS: menu validation and complete asynchronous order lifecycle");

    // Exercise the actual QueueTrigger's at-least-once delivery path by replaying a message.
    var queue = new QueueClient("UseDevelopmentStorage=true", "order-processing-queue", new QueueClientOptions { MessageEncoding = QueueMessageEncoding.Base64 });
    await queue.SendMessageAsync(JsonSerializer.Serialize(firstPayload, jsonOptions));
    await Task.Delay(2500);
    var replayed = await Call("GET", "/orders/status/" + firstId);
    Assert(replayed.GetProperty("history").GetArrayLength() == 4, "Completed duplicate delivery does not append extra history");
    Assert(replayed.GetProperty("status").GetString() == "Collected", "Completed duplicate delivery stays completed");
    var rows = await Call("GET", "/orders?date=" + date);
    Assert(rows.EnumerateArray().Count(x => x.GetProperty("orderId").GetString() == firstId) == 1, "Duplicate queue delivery creates no duplicate Table row");

    // A persisted Preparing row simulates a worker retry/restart halfway through an order.
    var resumedId = $"ORD-RESUME-{suffix}";
    var resumeTime = DateTimeOffset.UtcNow;
    var table = new TableClient("UseDevelopmentStorage=true", "Orders");
    var events = new[] { new { Status = "Received", Timestamp = resumeTime.AddSeconds(-1) }, new { Status = "Preparing", Timestamp = resumeTime } };
    await table.AddEntityAsync(new TableEntity(date, resumedId) { ["CustomerName"] = "Retry tester", ["SelectedItemSKUs"] = JsonSerializer.Serialize(new[] { fixtureId }),
        ["TotalPrice"] = 20.25, ["OrderTimestamp"] = resumeTime, ["Status"] = "Preparing", ["StatusHistory"] = JsonSerializer.Serialize(events) });
    await queue.SendMessageAsync(JsonSerializer.Serialize(new { OrderId = resumedId, CustomerName = "Retry tester", SelectedItemSKUs = new[] { fixtureId }, TotalPrice = 20.25m, OrderTimestamp = resumeTime }, jsonOptions));
    var resumed = await AwaitCollected(resumedId);
    Assert(resumed.GetProperty("history")[0].GetProperty("timestamp").GetDateTimeOffset() == events[0].Timestamp, "Retry preserves the original Received event");
    Console.WriteLine("PASS: duplicate queue delivery and recovery from persisted Preparing status");

    var submissions = await Task.WhenAll(Enumerable.Range(0, 8).Select(i => Call("POST", "/orders/queue", new { OrderId = $"ORD-LOAD-{suffix}-{i}", CustomerName = $"Student {i}", SelectedItemSKUs = new[] { fixtureId } }, HttpStatusCode.Accepted)));
    Assert(submissions.Length == 8, "Eight simultaneous submissions accepted");
    var batch = await Task.WhenAll(submissions.Select(x => AwaitCollected(x.GetProperty("orderId").GetString()!)));
    Assert(batch.All(x => x.GetProperty("totalPrice").GetDecimal() == 20.25m), "All concurrent orders use the current server price");
    Console.WriteLine("PASS: concurrent students complete independently");

    const string guide = "CoffeeNChill integration document: streamed round trip.";
    using (var multipart = new MultipartFormDataContent())
    {
        multipart.Add(new StringContent(guide), "file", fixtureName);
        using var response = await http.PostAsync("/api/documents/upload", multipart);
        Assert(response.StatusCode == HttpStatusCode.Created, "Multipart document upload");
    }
    var files = await Call("GET", "/documents");
    Assert(files.EnumerateArray().Any(x => x.GetProperty("fileName").GetString() == fixtureName), "Uploaded file appears in staff library");
    Assert(await http.GetStringAsync("/api/documents/download/" + fixtureName) == guide, "Streamed download matches original bytes");
    using (var unsafeUpload = new MultipartFormDataContent())
    {
        unsafeUpload.Add(new StringContent(guide), "file", "safe.txt");
        using var response = await http.PostAsync("/api/documents/upload?fileName=..%2Foutside.txt", unsafeUpload);
        Assert(response.StatusCode == HttpStatusCode.BadRequest, "Traversal filename rejected");
    }
    var oversizedName = $"oversized-{suffix}.txt";
    using (var oversized = new MultipartFormDataContent())
    {
        oversized.Add(new ByteArrayContent(new byte[10 * 1024 * 1024 + 1]), "file", oversizedName);
        using var response = await http.PostAsync("/api/documents/upload", oversized);
        Assert(response.StatusCode == HttpStatusCode.BadRequest, "10 MB upload limit enforced");
    }
    files = await Call("GET", "/documents");
    Assert(!files.EnumerateArray().Any(x => x.GetProperty("fileName").GetString() == oversizedName), "Rejected upload leaves no partial file");
    await Call("GET", "/documents/download/missing-file.txt", expected: HttpStatusCode.NotFound);
    Console.WriteLine("PASS: document round trip, path validation and bounded streaming");

    await Call("DELETE", $"/menu/Hot%20Drinks/{fixtureId}", expected: HttpStatusCode.NoContent);
    var afterDelete = await Call("GET", "/menu");
    Assert(!afterDelete.EnumerateArray().Any(x => x.GetProperty("id").GetString() == fixtureId), "Deleted menu item is absent");
    await Call("DELETE", $"/menu/Hot%20Drinks/{fixtureId}", expected: HttpStatusCode.NotFound);
    Console.WriteLine($"SUCCESS: {assertions} assertions passed against real Azure Functions / Azurite.");
}
catch (Exception exception)
{
    Console.Error.WriteLine(exception.Message);
    Environment.ExitCode = 1;
}
