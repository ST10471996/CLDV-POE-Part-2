param([int]$Port = 7071)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$functionRoot = Join-Path $projectRoot 'src/CoffeeNChill.Functions'
Get-Command dotnet, func -ErrorAction Stop | Out-Null
$azuriteCommand = Get-Command azurite -ErrorAction Stop
$settingsPath = Join-Path $functionRoot 'local.settings.json'
if (!(Test-Path -LiteralPath $settingsPath)) {
    Copy-Item -LiteralPath (Join-Path $functionRoot 'local.settings.example.json') -Destination $settingsPath
}
$azuritePath = Join-Path $functionRoot 'data/azurite'
New-Item -ItemType Directory -Force -Path $azuritePath | Out-Null
Write-Host 'Starting Azurite and the Azure Functions host. Press Ctrl+C to stop.'
# Use one owned PowerShell job, and stop it in finally; no orphaned background window.
$azuriteJob = Start-Job -ArgumentList $azuriteCommand.Source, $azuritePath -ScriptBlock {
    param($commandPath, $storagePath)
    & $commandPath --location $storagePath --silent --skipApiVersionCheck
}
try {
    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        if ($azuriteJob.State -eq 'Failed' -or $azuriteJob.State -eq 'Completed') {
            Receive-Job $azuriteJob
            throw 'Azurite exited. Check for occupied ports 10000, 10001 and 10002.'
        }
        $tcp = [System.Net.Sockets.TcpClient]::new()
        try { $tcp.Connect('127.0.0.1', 10002); $ready = $true }
        catch { Start-Sleep -Milliseconds 500 }
        finally { $tcp.Dispose() }
        if ($ready) { break }
    }
    if (!$ready) { throw 'Azurite did not become ready.' }
    Push-Location $functionRoot
    try { Write-Host "Dashboard: http://localhost:$Port/api/app"; func start --port $Port }
    finally { Pop-Location }
}
finally { Stop-Job $azuriteJob; Remove-Job $azuriteJob }
