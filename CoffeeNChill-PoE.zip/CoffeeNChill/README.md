# CoffeeNChill

**Good coffee. Better breaks.** A connected campus canteen built with C# Azure Functions, Azure Storage and Docker.

CoffeeNChill replaces chalkboard menus and scattered staff documents with a single canteen application. That foundation continues into asynchronous ordering: students submit their favourites, receive an immediate acknowledgement, and follow their order through **Received → Preparing → Ready → Collected**.

The menu, staff library and new order board share one interface, one Functions app and one repository. This is the current **v2.0** application; the menu and document features remain available alongside the new queue workflow.

![CoffeeNChill shared ordering dashboard](docs/dashboard-preview.png)

## What you can do

- Browse and search the menu, filter categories and build a basket.
- Submit an order without waiting for preparation to finish.
- Follow actual stored status changes on the live order board.
- View the day's order count, preparation activity and order value.
- Create menu items, change prices, toggle availability and remove items.
- Upload, list and download staff documents.

The preparation steps are an automatic **coursework simulation**. Each transition lasts four seconds by default; this includes the transition to Collected. It does not claim a student has physically collected an order. No real payment is taken.

## Start here

Open a terminal in this repository folder. Choose one of the two setup paths below.

### Local development

Install the **.NET 8 SDK**, **Node.js 22 or later**, and **Azure Functions Core Tools v4**. Use the .NET 8 SDK for this project even if another SDK is also installed.

```powershell
npm install -g azurite azure-functions-core-tools@4 --unsafe-perm true
Copy-Item ./src/CoffeeNChill.Functions/local.settings.example.json ./src/CoffeeNChill.Functions/local.settings.json
./scripts/start-local.ps1
```

The script starts Azurite and the Functions host. Open [the canteen dashboard](http://localhost:7071/api/app), then click **Add sample menu**. It inserts nine sample items and preserves any existing entries. Stop the services with Ctrl+C.

If you prefer separate terminals, start Azurite in the first:

```powershell
azurite --location ./data/azurite --silent --skipApiVersionCheck
```

In the second, from the repository root:

```powershell
cd ./src/CoffeeNChill.Functions
func start --port 7071
```

The local settings use `UseDevelopmentStorage=true`, which is correct when both services run on your computer. Keep `local.settings.json` out of Git.

### Published images and Docker Compose

Install Docker Desktop with **Linux containers** enabled. Create your own public Docker Hub repositories `coffeenchill-functions` and `coffeenchill-azurite`.

Publish the images under your actual Docker Hub account:

```powershell
./scripts/publish-images.ps1 -DockerHubUsername YOUR_DOCKERHUB_USERNAME
Copy-Item .env.example .env
```

Edit `.env` and replace `DOCKERHUB_USERNAME` with the same username. After the images have been pushed:

```powershell
docker compose pull
docker compose up
```

On systems with the older Compose executable, the equivalent startup command is `docker-compose up`.

Open [the canteen dashboard](http://localhost:7071/api/app). The root `docker-compose.yml` references **your published images**:

```text
YOUR_DOCKERHUB_USERNAME/coffeenchill-functions:v2.0
YOUR_DOCKERHUB_USERNAME/coffeenchill-azurite:v1.0
```

It contains no `build:` entries. Azurite must pass its health check before the Functions host starts. Storage and local staff documents persist in named volumes. `docker compose down` stops the services and keeps those volumes.

The container connection string uses `http://azurite:PORT/devstoreaccount1`, because `localhost` inside the Functions container points to that container. The account key in this development connection string is Azurite's public emulator key.

## Staff documents: local or real Azure Files

**Azurite does not emulate Azure Files.** It supports Blobs, Queues and Tables. Its standard ports are **10000 = Blobs, 10001 = Queues, 10002 = Tables**. These correct two inconsistencies in the supplied assignment brief. See [Microsoft's Azurite documentation](https://learn.microsoft.com/en-us/azure/storage/common/storage-use-azurite) and [port configuration](https://learn.microsoft.com/en-us/azure/storage/common/storage-install-azurite).

The application supports both document modes:

| Setting | Document storage | Use |
| --- | --- | --- |
| `DocumentsProvider=Local` | A persistent local folder / Docker volume | Development without an Azure subscription |
| `DocumentsProvider=AzureFiles` | A real Azure File Share named `staff-docs` | Demonstrating the assignment's Azure Files requirement |

Local mode **does not demonstrate real Azure Files**. For marking of the Azure File Share requirement, create an Azure Storage account that supports file shares, obtain its connection string and configure the AzureFiles mode. The application creates `staff-docs` if it does not exist, provided the credentials permit this.

For Compose, set these values in your ignored `.env` file:

```text
DOCUMENTS_PROVIDER=AzureFiles
AZURE_FILES_CONNECTION_STRING=YOUR_REAL_STORAGE_CONNECTION_STRING
```

Then apply the configuration with `docker compose up -d`. For `func start`, set `DocumentsProvider` to `AzureFiles` and `AzureFilesConnectionString` to the real connection string in `local.settings.json`. Restart the host.

The same upload, list and download routes work in both modes. Uploads accept a multipart field named `file`, with a 10 MB limit. In AzureFiles mode the multipart stream is sent to Azure Files in bounded blocks; it is not buffered as a whole document or staged to local disk. Supported names end in PDF, TXT, MD, DOCX, PNG or JPG. Existing file names are rejected; rename a new upload. The staff library and `/api/health` report the active mode.

## How the application fits together

```mermaid
flowchart LR
    UI[Dashboard / Postman] --> HTTP[HTTP Azure Functions]
    HTTP --> Menu[MenuItems Table]
    HTTP --> Docs[Staff documents]
    HTTP --> Queue[order-processing-queue]
    Queue --> Worker[ProcessOrderQueue]
    Worker --> Orders[Orders Table]
    Orders --> HTTP
    Docs --> Local[Local development folder]
    Docs --> Files[Real Azure File Share: staff-docs]
```

The document modes are alternatives selected by configuration. They are not dual writes. The isolated Functions app uses ASP.NET Core HTTP integration so chunked JSON requests and streamed multipart uploads work alongside the Queue trigger.

1. Menu entities use **PartitionKey = category** and **RowKey = SKU**. Price is stored as a Table-supported Double, rounded to two decimal places. SKUs should be unique across categories.
2. `POST /api/orders/queue` validates customer details, item availability and the current menu prices. When the optional client total is supplied, it must match the server's total. Repeated SKUs represent quantities; an order can contain 1–50 items.
3. The producer serializes the order as JSON and sends it to **order-processing-queue**, with the SDK configured for Base64 to match the Functions trigger. It immediately returns **202 Accepted**, an order ID and a status URL.
4. `ProcessOrderQueue` uses `[QueueTrigger("order-processing-queue", Connection = "AzureWebJobsStorage")]`. It parses the JSON, adds a Received row to **Orders**, and simulates the remaining stages.
5. Orders use **PartitionKey = UTC order date (`yyyy-MM-dd`)**, **RowKey = OrderId**. Arrays and status history are JSON strings because Azure Tables do not support array-valued properties. HTTP responses expose them as arrays.
6. Each status change saves a timestamp. The live board polls the order query endpoint every two seconds. An order may briefly return 404 while it waits for the queue consumer; this is expected.
7. Queue delivery is at least once. A repeated message for the same date and ID resumes its stored state. Completed rows are skipped. Table ETags prevent concurrent duplicate deliveries from moving a row backwards. Different payloads reusing the same stored key fail processing.

The trigger retries failed messages up to five times, with a 15-second retry visibility timeout. Persistent failures go to **order-processing-queue-poison**; inspect the host logs and correct the payload/configuration before replaying. IDs generated by the producer are unique. Client-supplied IDs are rejected once found in Orders; simultaneous submissions before the first row is created may both receive 202, with duplicate handling occurring in the consumer. This is not a global exactly-once guarantee.

These anonymous endpoints are intended for a local coursework environment. Compose exposes the app and emulator ports on loopback. Authentication and VPS deployment belong to the later project stage.

## HTTP routes

| Method | Route | Purpose / success |
| --- | --- | --- |
| POST | `/api/menu` | Create an item · 201 |
| GET | `/api/menu` | List the menu · 200 |
| GET | `/api/menu/category/{category}` | Filter by category · 200 |
| PUT | `/api/menu/{category}/{id}` | Update price and/or availability · 200 |
| DELETE | `/api/menu/{category}/{id}` | Remove an item · 204 |
| POST | `/api/documents/upload` | Upload multipart `file` · 201 |
| GET | `/api/documents` | List name, size and modified date · 200 |
| GET | `/api/documents/download/{fileName}` | Download the file stream · 200 |
| POST | `/api/orders/queue` | Validate and enqueue an order · 202 |
| GET | `/api/orders/status/{id}` | Read order and timestamped history · 200 |
| GET | `/api/orders?date=yyyy-MM-dd` | Read Orders by UTC date · 200 |
| GET | `/api/orders/queue-info` | Queue name and approximate count · 200 |
| POST | `/api/menu/seed` | Add sample menu entries · 200 |
| GET | `/api/health` | Verify storage connectivity and document mode · 200 |
| GET | `/api/app` | Open the dashboard · 200 |

URL-encode spaces and other characters in path parameters. Invalid JSON and validation failures return 400; missing resources return 404; duplicates and concurrent updates can return 409. Storage failures return 503 with details logged on the host.

Sample menu request:

```json
{
  "Category": "Hot Drinks",
  "Id": "COF-004",
  "Name": "Honey oat latte",
  "Description": "Espresso, oat milk and a little honey.",
  "Price": 44.00,
  "IsAvailable": true
}
```

Sample order request, after loading the unchanged sample menu:

```json
{
  "OrderId": "ORD-2026-8801",
  "CustomerName": "Jane Smith",
  "SelectedItemSKUs": ["COF-001", "PAS-104"],
  "TotalPrice": 65.00,
  "OrderTimestamp": "2026-10-12T10:15:00Z"
}
```

Omit `OrderId`, `TotalPrice` and `OrderTimestamp` to have the server generate the ID/time and calculate the price. For the dated example above, use `GET /api/orders?date=2026-10-12` to see it on that date's board.

## Verify with Postman

Import both files from `docs/`:

- `CoffeeNChill.postman_collection.json`
- `CoffeeNChill.local.postman_environment.json`

Select **CoffeeNChill · Local**. Set Postman's working directory to the repository root so `docs/sample-staff-guide.txt` resolves, or manually select the fixture in both multipart requests. Run the **entire collection in order** using Collection Runner. Clicking Send on the polling request alone will not execute the Runner loop.

The 34 requests retain coverage of the menu and document features and extend it through order placement, queue metadata, stored status history, validation, duplicate rejection and menu cleanup. The polling request repeats until Collected, then verifies the exact four-stage history and chronological timestamps. Each run creates unique IDs and a uniquely named document; the optional upload `fileName` query parameter supplies that name. Test orders/documents remain as evidence; the temporary menu item is removed.

If you changed the sample Espresso/Croissant prices or availability, restore them to R28/R37 and available before running the supplied order fixture. Seed preserves your edits and does not reset them.

For an automated run from this repository root:

```powershell
npm install -g newman
newman run ./docs/CoffeeNChill.postman_collection.json -e ./docs/CoffeeNChill.local.postman_environment.json --working-dir . --timeout-request 15000
```

For independent integration checks, including concurrent orders and queue-message replay:

```powershell
dotnet run --project ./tests/CoffeeNChill.Integration -- http://localhost:7071
```

Run this while Azurite and the Functions host are active in local development. It connects to the default local emulator to test queue redelivery directly. See [docs/VERIFICATION.md](docs/VERIFICATION.md) for the checks completed on this prepared version and their limits.

## Standalone containers: the retained foundation

You can still run each service individually without Compose. Use the published current application image and a shared Docker network:

```powershell
docker network create coffeenchill-network
docker run -d --name coffeenchill-azurite --network coffeenchill-network --network-alias azurite -p 127.0.0.1:10000:10000 -p 127.0.0.1:10001:10001 -p 127.0.0.1:10002:10002 YOUR_DOCKERHUB_USERNAME/coffeenchill-azurite:v1.0 azurite --blobHost 0.0.0.0 --queueHost 0.0.0.0 --tableHost 0.0.0.0 --skipApiVersionCheck
$storageConnection = 'DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://azurite:10000/devstoreaccount1;QueueEndpoint=http://azurite:10001/devstoreaccount1;TableEndpoint=http://azurite:10002/devstoreaccount1;'
docker run -d --name coffeenchill-functions --network coffeenchill-network -p 127.0.0.1:7071:80 -e "AzureWebJobsStorage=$storageConnection" -e DocumentsProvider=Local YOUR_DOCKERHUB_USERNAME/coffeenchill-functions:v2.0
```

These commands use the current v2.0 app. They do not recreate historical v1.0 source or claim an earlier submission exists.

## Repository map

```text
docker-compose.yml                    Published-image orchestration
src/CoffeeNChill.Functions/
  Functions/                          Menu, document, order and dashboard functions
  Models/                             Request/response and Azure Table contracts
  Services/                           Storage, streaming files, HTTP errors
  www/                                Responsive shared dashboard
  Dockerfile                          Multi-stage Functions image
  host.json                           Trigger and retry settings
  local.settings.example.json         Safe local configuration template
scripts/                              Local startup and Docker Hub publishing
docs/                                 Postman exports, fixture, demo and submission guide
tests/CoffeeNChill.Integration/        Real endpoint and queue-replay checks
CHANGELOG.md                          Continuous project evolution
```

## Project evolution

The current release adds asynchronous orders and Compose orchestration to the menu/document foundation. See [CHANGELOG.md](CHANGELOG.md) for the continuous changelog and [docs/DEMONSTRATION.md](docs/DEMONSTRATION.md) for the video walkthrough.

## Team contributions and submission links

Complete this table with real details before submitting. This prepared source does not include a published GitHub repository, Docker Hub uploads, a recorded presentation or a student's prior commit history.

| Evidence | Link / detail |
| --- | --- |
| GitHub repository | **TODO: your repository URL** |
| Functions image v2.0 | **TODO: public Docker Hub repository/tag URL** |
| Azurite image v1.0 | **TODO: public Docker Hub repository/tag URL** |
| Current unlisted YouTube demonstration | **TODO: paste the actual unlisted YouTube URL** |
| Previous demonstration, if applicable | **TODO: retain your earlier video URL** |

| Group member | Student number | Individual GitHub username | Work completed | Relevant commits |
| --- | --- | --- | --- | --- |
| Kagiso Masokwe | ST10472454 | ST10472454 | TODO: describe actual contribution | TODO: commit links |
| Keratilwe Mashampa | ST10471996 | ST10471996 | TODO: describe actual contribution | TODO: commit links |

Every student must use their own GitHub account and make at least **five meaningful commits for the current assignment stage**. Record genuine contributions; the lecturer checks the history. The video needs the running app, a human voiceover, architecture/design explanations, a single-command Compose startup and successful Postman execution. The supplied written outline is for a person to present.

Submit the **GitHub repository link** on the learning portal. Upload this source as repository files, not a ZIP. Use [docs/SUBMISSION.md](docs/SUBMISSION.md) to complete the remaining evidence.
