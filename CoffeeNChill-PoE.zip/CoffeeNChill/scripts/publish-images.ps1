param([Parameter(Mandatory = $true)][ValidatePattern('^[a-z0-9][a-z0-9_-]+$')][string]$DockerHubUsername)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Get-Command docker -ErrorAction Stop | Out-Null
Push-Location $projectRoot
try {
    Write-Host 'Sign in to your own Docker Hub account.'
    docker login
    if ($LASTEXITCODE -ne 0) { throw 'Docker Hub login failed.' }
    docker build --platform linux/amd64 -t "$DockerHubUsername/coffeenchill-functions:v2.0" ./src/CoffeeNChill.Functions
    if ($LASTEXITCODE -ne 0) { throw 'Functions build failed.' }
    docker push "$DockerHubUsername/coffeenchill-functions:v2.0"
    if ($LASTEXITCODE -ne 0) { throw 'Functions image push failed.' }
    docker pull --platform linux/amd64 mcr.microsoft.com/azure-storage/azurite:3.37.0
    if ($LASTEXITCODE -ne 0) { throw 'Azurite image pull failed.' }
    docker tag mcr.microsoft.com/azure-storage/azurite:3.37.0 "$DockerHubUsername/coffeenchill-azurite:v1.0"
    if ($LASTEXITCODE -ne 0) { throw 'Azurite image tagging failed.' }
    docker push "$DockerHubUsername/coffeenchill-azurite:v1.0"
    if ($LASTEXITCODE -ne 0) { throw 'Azurite image push failed.' }
    Write-Host 'Both images published. Set the same username in .env, then run docker compose up.'
}
finally { Pop-Location }
