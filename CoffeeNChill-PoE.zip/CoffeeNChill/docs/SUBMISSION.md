# CoffeeNChill · Finish your submission

The source is one continuous project. These remaining steps require your own accounts and actual evidence.

- [ ] Run the project and understand the menu, document and queue functions.
- [ ] Configure **real AzureFiles mode** to demonstrate `staff-docs`; local mode is only a development fallback.
- [ ] Create or use your team's GitHub repository and upload the source files.
- [ ] Each student commits and pushes genuine contributions with their individual account; verify at least five meaningful commits per person for the current stage.
- [ ] Build and publish `coffeenchill-functions:v2.0` and `coffeenchill-azurite:v1.0` to public Docker Hub repositories.
- [ ] Set the correct Docker Hub username in `.env`, pull the images and demonstrate `docker compose up`.
- [ ] Run the complete Postman collection successfully against that Compose instance.
- [ ] Record your running application with a human voiceover using `DEMONSTRATION.md` as an outline.
- [ ] Upload the video as unlisted to YouTube and paste its actual link into the root README.
- [ ] Complete the README contribution table and repository/image links.
- [ ] Submit the GitHub repository URL on the learning portal. No ZIP submission.

To start a new repository from this folder, after creating an empty GitHub repository:

```powershell
git init
git add .
git commit -m "Implement connected canteen menu, documents and queued ordering"
git branch -M main
git remote add origin YOUR_ACTUAL_GITHUB_REPOSITORY_URL
git push -u origin main
```

Configure Git to your own account before committing. This initial commit does not replace the assignment's required individual contributions. If you already have a Part 1 repository, copy these current files into that checkout, review changes and preserve your existing history.
