using System.Net;
using System.Text.Json;
using Azure;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Middleware;
using Microsoft.Extensions.Logging;

namespace CoffeeNChill.Functions.Services;

public sealed class ErrorMiddleware(ILogger<ErrorMiddleware> logger) : IFunctionsWorkerMiddleware
{
    public async Task Invoke(FunctionContext context, FunctionExecutionDelegate next)
    {
        try { await next(context); }
        catch (Exception exception)
        {
            var request = await context.GetHttpRequestDataAsync();
            if (request is null) throw; // Queue failures must reach the runtime's retry / poison queue mechanism.
            var (status, message) = exception switch
            {
                JsonException => (HttpStatusCode.BadRequest, "The request body must contain valid JSON with the expected field types."),
                InvalidDataException e => (HttpStatusCode.BadRequest, e.Message),
                FileNotFoundException => (HttpStatusCode.NotFound, "Document not found."),
                RequestFailedException { Status: 404 } => (HttpStatusCode.NotFound, "The requested item was not found."),
                RequestFailedException { Status: 409 or 412 } => (HttpStatusCode.Conflict, "This item already exists or was changed by another request. Refresh and try again."),
                _ => (HttpStatusCode.ServiceUnavailable, "Storage is currently unavailable. Check the service configuration and logs.")
            };
            logger.LogError(exception, "Function {Function} returned {Status}", context.FunctionDefinition.Name, status);
            context.GetInvocationResult().Value = await request.ErrorAsync(message, status);
        }
    }
}
