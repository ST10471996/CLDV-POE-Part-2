using System.Net;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker.Http;

namespace CoffeeNChill.Functions.Services;

public static class HttpResponses
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    public static async Task<HttpResponseData> JsonAsync(this HttpRequestData request, object value, HttpStatusCode status = HttpStatusCode.OK,
        Dictionary<string, string>? headers = null)
    {
        var response = request.CreateResponse(status);
        response.Headers.Add("Content-Type", "application/json; charset=utf-8");
        if (headers is not null) foreach (var header in headers) response.Headers.Add(header.Key, header.Value);
        await response.WriteStringAsync(JsonSerializer.Serialize(value, Json));
        return response;
    }
    public static Task<HttpResponseData> ErrorAsync(this HttpRequestData request, string error, HttpStatusCode status = HttpStatusCode.BadRequest) =>
        request.JsonAsync(new { error }, status);
    public static async Task<T?> ReadAsync<T>(this HttpRequestData request) => await JsonSerializer.DeserializeAsync<T>(request.Body, Json);
}
