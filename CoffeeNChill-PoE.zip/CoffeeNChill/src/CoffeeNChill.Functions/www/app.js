'use strict';
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = (value) => `R ${Number(value).toFixed(2)}`;
const iconPaths = {
  cup: '<path d="M5 8h11v8c0 5-11 5-11 0V8Zm11 2h2c6 0 6 7 0 7h-2M3 22h16M8 2v3m5-4v4"/>',
  board: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M9 9v12m6-12v12M7 1v5m10-5v5"/>',
  chart: '<path d="M4 3v18h17M8 16v-5m5 5V7m5 9V4"/>',
  folder: '<path d="M3 7h18v13H3V7Zm0 0V4h7l3 3"/>',
  menu: '<path d="M8 5h13M8 12h13M8 19h13M3 4v2m0 5v2m0 5v2"/>',
  search: '<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/>',
  refresh: '<path d="M20 7a9 9 0 1 0 1 9M20 2v6h-6"/>',
  plus: '<path d="M12 4v16M4 12h16"/>',
  upload: '<path d="M12 16V3m-5 5 5-5 5 5M3 16v5h18v-5"/>'
};
const icon = name => `<span class="icon" aria-hidden="true"><svg viewBox="0 0 24 24">${iconPaths[name] || iconPaths.cup}</svg></span>`;
$$('[data-icon]').forEach(el => el.innerHTML = icon(el.dataset.icon));
const state = { menu: [], orders: [], overviewOrders: [], documents: [], cart: new Map(), category: 'All', page: 'order', health: null, detail: null, editing: null, deleting: null, placing: false };
const pageLabels = {order:'Place an order',orders:'Live orders',overview:'Overview',documents:'Staff documents',menu:'Manage menu'};
let toastTimer;
function toast(message, error = false) {
  $('#toast').textContent = message;
  $('#toast').className = `toast${error ? ' error' : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('#toast').classList.add('hidden'), error ? 8500 : 6500);
}
async function api(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`/api${path}`, { ...options, signal: controller.signal });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body.error || `Request failed (${response.status}).`);
    }
    return response.status === 204 ? null : await response.json();
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('The service is taking too long. Check the connection and try again.');
    throw error;
  } finally { clearTimeout(timeout); }
}
const send = (path, method, value) => api(path, {method, headers:{'Content-Type':'application/json'}, body:JSON.stringify(value)});
const utcDate = () => new Date().toISOString().slice(0, 10);
function setConnection(online) {
  const el = $('#connection');
  el.classList.toggle('offline', !online);
  el.innerHTML = `<i></i>${online ? 'Canteen connected' : 'Connection unavailable'}`;
}
function illustration(category, index = 0) {
  const start = '<svg viewBox="0 0 150 130" aria-hidden="true">';
  const shadow = '<ellipse cx="75" cy="113" rx="43" ry="7" fill="#000" opacity=".06"/>';
  if (category === 'Pastries') return start + shadow + (index % 2 ? '<path d="M45 72h60l-8 38H53Z" fill="#ad8463"/><path d="M47 77v29m11-29v31m12-31v32m12-32v31m12-31v28" stroke="#d2af82" stroke-width="3"/><path d="M43 76c-10-21 8-43 21-36 10-25 29-15 32-4 22-1 29 24 13 40Z" fill="#6e4a37"/><circle cx="62" cy="52" r="4" fill="#412d21"/><circle cx="85" cy="42" r="4" fill="#412d21"/><circle cx="99" cy="60" r="4" fill="#412d21"/>' : '<g transform="translate(21 74) rotate(-10 54 12)"><path d="M0 9c12-52 96-52 109 0L91 29c-9-28-64-28-72 0Z" fill="#b47a3e"/><path d="M13 2c17-33 69-33 85 0L83 23c-12-20-46-20-58 0Z" fill="#dca55f"/><path d="m30-9 8 26m17-32v27m24-22-9 26" stroke="#f4c885" stroke-width="6"/></g>') + '</svg>';
  if (category === 'Sandwiches') return start + shadow + '<path d="M25 93 72 28l53 65-50 17Z" fill="#c6985f"/><path d="M28 86 72 24l49 61-45 17Z" fill="#f4dab0"/><path d="m33 89 41 15 43-14" stroke="#547c48" stroke-width="6"/><path d="m35 94 39 13 41-13" stroke="#d9ac59" stroke-width="5"/><path d="M49 60h9m4 15h9m7-30h5m8  twenty" stroke="#d3b98c" stroke-width="2" stroke-linecap="round"/>' + '</svg>';
  if (category === 'Cold Drinks') return start + shadow + '<path d="M80 17 65 84" stroke="#55755d" stroke-width="5" stroke-linecap="round"/><path d="M46 41h61l-10 68H55Z" fill="#ffffffa8" stroke="#c4d7c5" stroke-width="2"/><path d="M50 59h52l-7 48H57Z" fill="' + (index % 2 ? '#c48d4d' : '#ad8662') + '" opacity=".8"/><rect x="58" y="63" width="15" height="15" rx="3" fill="#fff" opacity=".45" transform="rotate(12 66 70)"/><rect x="80" y="78" width="13" height="13" rx="3" fill="#fff" opacity=".45" transform="rotate(-12 85 85)"/><ellipse cx="76" cy="41" rx="31" ry="5" fill="#fafcf7" stroke="#c4d7c5"/>' + '</svg>';
  return start + shadow + '<path d="M42 55h61v28c0 34-61 34-61 0Z" fill="#fcf9ee"/><path d="M102 62h9c24 0 24 31 0 31h-10" fill="none" stroke="#fcf9ee" stroke-width="8"/><ellipse cx="72" cy="55" rx="31" ry="7" fill="#d9c6ac"/><ellipse cx="72" cy="55" rx="25" ry="5" fill="#85593b"/><path d="M82 30c-8-10 8-15 0-24" fill="none" stroke="#a0a38d" stroke-width="2" stroke-linecap="round"/><path d="M58 77h29m-23 7h17" stroke="#d6c7a9" stroke-width="2" stroke-linecap="round"/>' + '</svg>';
}
function renderMenu() {
  const categories = ['All', ...new Set(state.menu.map(item => item.category))];
  $('#filters').innerHTML = categories.map(category => `<button class="filter${state.category === category ? ' active' : ''}" data-filter="${escapeHtml(category)}" aria-pressed="${state.category === category}">${escapeHtml(category === 'All' ? 'All favourites' : category)}</button>`).join('');
  const query = $('#search').value.trim().toLowerCase();
  const menu = state.menu.filter(item => (state.category === 'All' || item.category === state.category) && `${item.name} ${item.description} ${item.id}`.toLowerCase().includes(query));
  if (!state.menu.length) {
    $('#menu-grid').innerHTML = '<div class="empty"><h3>Bring the menu to life.</h3><p>Add your own favourites in Manage menu,<br>or start with our sample campus menu.</p><button class="button primary" data-seed>Add sample menu ↗</button></div>';
    return;
  }
  $('#menu-grid').innerHTML = menu.length ? menu.map((item, index) => `<article class="menu-card"><div class="card-art ${item.category === 'Cold Drinks' ? 'cold' : item.category === 'Pastries' ? 'pastry' : item.category === 'Sandwiches' ? 'sandwich' : ''}"><span class="category-badge">${escapeHtml(item.category)}</span>${illustration(item.category,index)}</div><div class="card-content"><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.description)}</p><div class="card-bottom"><span class="price">${money(item.price)}</span>${item.isAvailable ? `<button class="add-item" data-add="${escapeHtml(item.id)}" aria-label="Add ${escapeHtml(item.name)} to your order">+</button>` : '<span class="sold-out">Taking a little break</span>'}</div></div></article>`).join('') : '<div class="empty"><p>No favourites found. Try another search.</p></div>';
  renderManagement();
}
function renderCart() {
  let total = 0, count = 0;
  const lines = [];
  for (const [id, quantity] of state.cart) {
    const item = state.menu.find(x => x.id === id);
    if (!item || !item.isAvailable) { state.cart.delete(id); continue; }
    total += item.price * quantity; count += quantity;
    lines.push(`<div class="cart-line"><div class="cart-line-name"><strong>${escapeHtml(item.name)}</strong><span>${money(item.price)}</span></div><div class="quantity"><button data-quantity="${escapeHtml(id)}" data-change="-1" aria-label="Remove one ${escapeHtml(item.name)}">−</button><span>${quantity}</span><button data-quantity="${escapeHtml(id)}" data-change="1" aria-label="Add one ${escapeHtml(item.name)}">+</button></div></div>`);
  }
  $('#cart-items').innerHTML = lines.length ? lines.join('') : `<div class="cart-empty">${icon('cup')}<p>Your break starts here.</p><small>Add a favourite from the menu.</small></div>`;
  $('#cart-total').textContent = money(total); $('#cart-count').textContent = count;
  $('#place-order').disabled = !count || state.placing;
  $('#place-order').innerHTML = state.placing ? 'Sending your order…' : 'Place order<span>↗</span>';
}
async function loadMenu() { state.menu = await api('/menu'); renderMenu(); renderCart(); renderManagement(); }
async function seedMenu() {
  try { const result = await send('/menu/seed','POST',{}); await loadMenu(); toast(`${result.added} sample favourites added. Existing items kept.`); }
  catch(error) { toast(error.message,true); }
}
async function placeOrder() {
  const customerName = $('#customer').value.trim();
  if (!customerName) { toast('Add your name so we know who to call.',true); $('#customer').focus(); return; }
  state.placing = true; renderCart();
  try {
    const selectedItemSKUs = [...state.cart].flatMap(([id, quantity]) => Array(quantity).fill(id));
    const result = await send('/orders/queue','POST',{customerName,selectedItemSKUs});
    state.cart.clear(); renderCart(); $('#order-date').value = result.orderTimestamp.slice(0,10);
    state.detail = result.orderId;
    await navigate('orders');
    toast(`You're in, ${customerName}! Order ${result.orderId} is queued. It will appear on the board shortly.`);
  } catch(error) { toast(error.message,true); }
  finally { state.placing = false; renderCart(); }
}
function renderOrders() {
  $('#nav-count').textContent = state.orders.filter(x => x.status !== 'Collected').length;
  $('#order-board').innerHTML = ['Received','Preparing','Ready','Collected'].map(status => {
    const orders = state.orders.filter(x => x.status === status);
    return `<section class="board-column ${status.toLowerCase()}"><div class="column-heading"><i></i>${status}<span class="count">${orders.length}</span></div>${orders.length ? orders.map(order => `<button class="order-card" data-order="${escapeHtml(order.orderId)}"><span class="order-id">${escapeHtml(order.orderId)}</span><strong>${escapeHtml(order.customerName)}</strong><small>${order.selectedItemSKUs.length} item${order.selectedItemSKUs.length === 1 ? '' : 's'} · ${escapeHtml(order.selectedItemSKUs.map(id => state.menu.find(x => x.id === id)?.name || id).join(', '))}</small><div class="order-card-bottom"><b>${money(order.totalPrice)}</b><span>${new Date(order.orderTimestamp).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</span></div></button>`).join('') : '<p class="column-empty">A little breathing room.<br>No orders here yet.</p>'}</section>`;
  }).join('');
  const order = state.orders.find(x => x.orderId === state.detail);
  $('#order-detail').classList.toggle('hidden', !state.detail);
  if (state.detail) $('#order-detail').innerHTML = order ? `<h2>${escapeHtml(order.customerName)}’s little break</h2><p>${escapeHtml(order.orderId)} · ${money(order.totalPrice)}</p><div class="timeline">${['Received','Preparing','Ready','Collected'].map(status => { const event = order.history.find(x => x.status === status); return `<div class="timeline-step${event ? ' done' : ''}">${status}<small>${event ? new Date(event.timestamp).toLocaleTimeString() : 'Coming up'}</small></div>`; }).join('')}</div>` : '<h2>Your order is on its way.</h2><p>Waiting for the preparation team to receive the queued order…</p>';
}
async function loadOrders() { state.orders = await api(`/orders?date=${encodeURIComponent($('#order-date').value || utcDate())}`); renderOrders(); }
async function loadOverview() {
  state.overviewOrders = await api(`/orders?date=${utcDate()}`);
  const orders = state.overviewOrders;
  $('#stats').innerHTML = [
    ['Orders today',orders.length,'Every order, every little break'],
    ['In preparation',orders.filter(x => ['Received','Preparing'].includes(x.status)).length,'With the team behind the counter'],
    ['Ready to collect',orders.filter(x => x.status === 'Ready').length,'Good things waiting for their people'],
    ['Order value',money(orders.reduce((sum,x) => sum+x.totalPrice,0)),'Total value of today’s received orders']
  ].map(([label,value,note]) => `<div class="stat"><span>${label}</span><strong>${value}</strong><small>${note}</small></div>`).join('');
  $('#recent-orders').innerHTML = orders.length ? orders.slice(0,8).map(x => `<div class="recent-row"><div><strong>${escapeHtml(x.customerName)}</strong><small>${escapeHtml(x.orderId)}</small></div><span class="status-badge">${x.status}</span><b>${money(x.totalPrice)}</b></div>`).join('') : '<div class="empty"><p>It’s a fresh start. Today’s orders will appear here.</p></div>';
}
async function loadDocuments() {
  state.documents = await api('/documents');
  $('#provider-note').textContent = state.health?.documentsProvider === 'AzureFiles' ? 'Shared with the team through Azure Files · staff-docs' : 'Local document mode is active. To use the shared Azure Files library, configure AzureFilesConnectionString and DocumentsProvider=AzureFiles.';
  $('#documents-table').innerHTML = state.documents.length ? state.documents.map(x => `<tr><td><strong>${escapeHtml(x.fileName)}</strong><small>Staff library</small></td><td>${x.size >= 1048576 ? `${(x.size/1048576).toFixed(1)} MB` : `${Math.max(1,Math.round(x.size/1024))} KB`}</td><td>${new Date(x.lastModified).toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'})}</td><td><a class="button secondary" href="/api/documents/download/${encodeURIComponent(x.fileName)}" download>Download ↓</a></td></tr>`).join('') : '<tr><td class="table-empty" colspan="4">A fresh space for the team’s knowledge. Upload your first document.</td></tr>';
}
async function uploadDocument(file) {
  if (!file) return;
  if (file.size > 10 * 1024 * 1024) { toast('Choose a file smaller than 10 MB.',true); return; }
  $('#upload-button').disabled = true;
  const data = new FormData(); data.append('file',file);
  try { await api('/documents/upload',{method:'POST',body:data}); await loadDocuments(); toast(`${file.name} is ready for the team.`); }
  catch(error) { toast(error.message,true); }
  finally { $('#upload-button').disabled = false; $('#document-file').value = ''; }
}
function renderManagement() {
  $('#menu-summary').textContent = `${state.menu.length} favourites · ${state.menu.filter(x => x.isAvailable).length} available today`;
  $('#management-table').innerHTML = state.menu.length ? state.menu.map(x => `<tr><td><strong>${escapeHtml(x.name)}</strong><small>${escapeHtml(x.id)}</small></td><td>${escapeHtml(x.category)}</td><td>${money(x.price)}</td><td><button class="availability${x.isAvailable ? '' : ' off'}" data-toggle="${escapeHtml(x.id)}" aria-label="Toggle ${escapeHtml(x.name)} availability"><i></i>${x.isAvailable ? 'Available' : 'Unavailable'}</button></td><td><div class="actions"><button class="button secondary" data-edit="${escapeHtml(x.id)}">Edit</button><button class="button secondary" data-delete="${escapeHtml(x.id)}">Remove</button></div></td></tr>`).join('') : '<tr><td colspan="5" class="table-empty">Add a menu item or load the sample menu to get started.</td></tr>';
}
function menuPath(item) { return `/menu/${encodeURIComponent(item.category)}/${encodeURIComponent(item.id)}`; }
function openMenu(item = null) {
  state.editing = item;
  const form = $('#menu-form'); form.reset();
  $('#dialog-title').textContent = item ? 'Keep it fresh.' : 'Something new?';
  ['name','category','id','description'].forEach(key => {form.elements[key].disabled = !!item; if(item) form.elements[key].value = item[key];});
  if(item) { form.elements.price.value = item.price; form.elements.isAvailable.value = String(item.isAvailable); }
  $('#edit-note').hidden = !item;
  $('#menu-dialog').showModal();
}
async function saveMenu(event) {
  event.preventDefault();
  const form = event.target, submit = form.querySelector('[type="submit"]');
  const input = {name:form.elements.name.value.trim(),category:form.elements.category.value,id:form.elements.id.value.trim(),description:form.elements.description.value.trim(),price:Number(form.elements.price.value),isAvailable:form.elements.isAvailable.value === 'true'};
  submit.disabled = true;
  try { await send(state.editing ? menuPath(state.editing) : '/menu',state.editing ? 'PUT' : 'POST',state.editing ? {price:input.price,isAvailable:input.isAvailable} : input); await loadMenu(); $('#menu-dialog').close(); toast('The menu is looking fresh. Changes saved.'); }
  catch(error) { toast(error.message,true); }
  finally { submit.disabled = false; }
}
async function toggleMenu(id) {
  const item = state.menu.find(x => x.id === id);
  try { await send(menuPath(item),'PUT',{isAvailable:!item.isAvailable}); await loadMenu(); toast(`${item.name} is now ${item.isAvailable ? 'unavailable' : 'available'}.`); }
  catch(error) { toast(error.message,true); }
}
async function removeMenu() {
  const item = state.deleting; $('#confirm-delete').disabled = true;
  try { await api(menuPath(item),{method:'DELETE'}); await loadMenu(); $('#delete-dialog').close(); toast(`${item.name} was removed from the menu.`); }
  catch(error) { toast(error.message,true); }
  finally { $('#confirm-delete').disabled = false; }
}
async function navigate(page) {
  if (!pageLabels[page]) page = 'order';
  state.page = page;
  window.scrollTo(0,0);
  $$('.page').forEach(el => el.classList.toggle('hidden',el.id !== `page-${page}`));
  $$('.nav-button').forEach(el => {el.classList.toggle('active',el.dataset.page === page);el.setAttribute('aria-current',el.dataset.page === page ? 'page' : 'false');});
  $('#page-label').textContent = pageLabels[page];
  if (location.hash !== `#${page}`) history.replaceState(null,'',`#${page}`);
  try { if(page === 'orders') await loadOrders(); if(page === 'overview') await loadOverview(); if(page === 'documents') await loadDocuments(); if(page === 'menu') await loadMenu(); }
  catch(error) { toast(error.message,true); }
}
document.addEventListener('click',event => {
  const el = event.target.closest('button,[data-page]'); if(!el) return;
  if(el.dataset.page) navigate(el.dataset.page);
  if(el.dataset.filter) {state.category = el.dataset.filter;renderMenu();}
  if(el.hasAttribute('data-seed')) seedMenu();
  if(el.dataset.add || el.dataset.quantity) {
    const count = [...state.cart.values()].reduce((sum,x) => sum+x,0);
    if(count >= 50 && Number(el.dataset.change || 1) > 0) {toast('One order can contain up to 50 items.',true);return;}
    const id = el.dataset.add || el.dataset.quantity, next = (state.cart.get(id) || 0) + Number(el.dataset.change || 1);
    if(next <= 0) state.cart.delete(id); else state.cart.set(id,next); renderCart();
  }
  if(el.dataset.order) {state.detail = el.dataset.order;renderOrders();$('#order-detail').scrollIntoView({behavior:'smooth',block:'nearest'});}
  if(el.dataset.edit) openMenu(state.menu.find(x => x.id === el.dataset.edit));
  if(el.dataset.toggle) toggleMenu(el.dataset.toggle);
  if(el.dataset.delete) {state.deleting = state.menu.find(x => x.id === el.dataset.delete);$('#delete-message').textContent = `${state.deleting.name} will be removed from the campus menu.`;$('#delete-dialog').showModal();}
});
$('#search').addEventListener('input',renderMenu);
$('#place-order').addEventListener('click',placeOrder);
$('#refresh-orders').addEventListener('click',() => loadOrders().catch(error => toast(error.message,true)));
$('#order-date').addEventListener('change',() => {state.detail=null;loadOrders().catch(error => toast(error.message,true));});
$('#seed-menu').addEventListener('click',seedMenu);
$('#add-menu').addEventListener('click',() => openMenu());
$('#close-dialog').addEventListener('click',() => $('#menu-dialog').close());
$('#menu-form').addEventListener('submit',saveMenu);
$('#cancel-delete').addEventListener('click',() => $('#delete-dialog').close());
$('#confirm-delete').addEventListener('click',removeMenu);
$('#upload-button').addEventListener('click',() => $('#document-file').click());
$('#choose-file').addEventListener('click',() => $('#document-file').click());
$('#document-file').addEventListener('change',event => uploadDocument(event.target.files[0]));
$('#drop-zone').addEventListener('dragover',event => {event.preventDefault();$('#drop-zone').classList.add('dragging');});
$('#drop-zone').addEventListener('dragleave',() => $('#drop-zone').classList.remove('dragging'));
$('#drop-zone').addEventListener('drop',event => {event.preventDefault();$('#drop-zone').classList.remove('dragging');uploadDocument(event.dataTransfer.files[0]);});
window.addEventListener('hashchange',() => navigate(location.hash.slice(1)));
$('#today').textContent = new Date().toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short',year:'numeric'});
$('#order-date').value = utcDate(); renderCart();
async function initialize() {
  try { state.health = await api('/health');setConnection(true);await loadMenu();await loadOrders();await navigate(location.hash.slice(1) || 'order'); }
  catch(error) {setConnection(false);$('#menu-grid').innerHTML='<div class="empty"><h3>The canteen is taking a moment.</h3><p>Start the services, then refresh this page.<br>Check the README for the local setup steps.</p></div>';toast(error.message,true);}
}
initialize();
let refreshing = false;
setInterval(async () => {
  if(document.hidden || refreshing) return;
  refreshing = true;
  try {
    if(state.page === 'orders') await loadOrders();
    else if(state.page === 'overview') await loadOverview();
    else {
      await api('/health');
      if(state.page === 'order' || state.page === 'menu') {
        const menu = await api('/menu');
        if(JSON.stringify(menu) !== JSON.stringify(state.menu)) {state.menu=menu;renderMenu();renderCart();renderManagement();}
      }
    }
    setConnection(true);
  }
  catch {setConnection(false);}
  finally {refreshing = false;}
},2000);
