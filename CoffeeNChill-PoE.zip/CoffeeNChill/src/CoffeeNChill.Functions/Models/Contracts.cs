using System.Text.Json;
using Azure;
using Azure.Data.Tables;

namespace CoffeeNChill.Functions.Models;

public sealed record MenuInput(string? Category, string? Id, string? Name, string? Description, double Price, bool IsAvailable = true);
public sealed record MenuUpdate(double? Price, bool? IsAvailable);
public sealed record MenuView(string Category, string Id, string Name, string Description, double Price, bool IsAvailable);
public sealed record OrderInput(string? OrderId, string? CustomerName, string[]? SelectedItemSKUs, decimal? TotalPrice, DateTimeOffset? OrderTimestamp);
public sealed record OrderMessage(string OrderId, string CustomerName, string[] SelectedItemSKUs, decimal TotalPrice, DateTimeOffset OrderTimestamp);
public sealed record OrderEvent(string Status, DateTimeOffset Timestamp);
public sealed record OrderView(string OrderId, string CustomerName, string[] SelectedItemSKUs, decimal TotalPrice,
    DateTimeOffset OrderTimestamp, string OrderDate, string Status, OrderEvent[] History);
public sealed record DocumentView(string FileName, long Size, DateTimeOffset LastModified);

public sealed class MenuEntity : ITableEntity
{
    public string PartitionKey { get; set; } = "";
    public string RowKey { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public double Price { get; set; }
    public bool IsAvailable { get; set; }
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }
    public MenuView View() => new(PartitionKey, RowKey, Name, Description, Price, IsAvailable);
}

public sealed class OrderEntity : ITableEntity
{
    public string PartitionKey { get; set; } = "";
    public string RowKey { get; set; } = "";
    public string CustomerName { get; set; } = "";
    public string SelectedItemSKUs { get; set; } = "[]";
    public double TotalPrice { get; set; }
    public DateTimeOffset OrderTimestamp { get; set; }
    public string Status { get; set; } = "Received";
    public string StatusHistory { get; set; } = "[]";
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }
    public OrderView View() => new(RowKey, CustomerName, JsonSerializer.Deserialize<string[]>(SelectedItemSKUs) ?? [],
        (decimal)TotalPrice, OrderTimestamp, PartitionKey, Status, JsonSerializer.Deserialize<OrderEvent[]>(StatusHistory) ?? []);
}
